<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 8/11/2015
 * Time: 8:55 AM
 */
class G5Plus_Widget_About extends G5Plus_Widget {
	public function __construct() {
		$this->widget_cssclass    = 'widget-about';
		$this->widget_description = __( "About Widget", 'g5plus-wolverine' );
		$this->widget_id          = 'g5plus-about';
		$this->widget_name        = __( 'G5Plus: About', 'g5plus-wolverine' );
		$this->settings           = array(
			'title' => array(
				'type' => 'text',
				'std' => '',
				'label' => __('Title','g5plus-wolverine')
			),
			'avatar' => array(
				'type' => 'image',
				'std' => '',
				'label' => __('Avatar','g5plus-wolverine')
			),
			'social' => array(
				'type'  => 'multi-select',
				'label'   => __( 'Select social profiles', 'g5plus-wolverine' ),
				'std'   => '',
				'options' => array(
					'twitter'  => __( 'Twitter', 'g5plus-wolverine' ),
					'facebook'  => __( 'Facebook', 'g5plus-wolverine' ),
					'dribbble'  => __( 'Dribbble', 'g5plus-wolverine' ),
					'vimeo'  => __( 'Vimeo', 'g5plus-wolverine' ),
					'tumblr'  => __( 'Tumblr', 'g5plus-wolverine' ),
					'skype'  => __( 'Skype', 'g5plus-wolverine' ),
					'linkedin'  => __( 'LinkedIn', 'g5plus-wolverine' ),
					'googleplus'  => __( 'Google+', 'g5plus-wolverine' ),
					'flickr'  => __( 'Flickr', 'g5plus-wolverine' ),
					'youtube'  => __( 'YouTube', 'g5plus-wolverine' ),
					'pinterest' => __( 'Pinterest', 'g5plus-wolverine' ),
					'foursquare'  => __( 'Foursquare', 'g5plus-wolverine' ),
					'instagram' => __( 'Instagram', 'g5plus-wolverine' ),
					'github'  => __( 'GitHub', 'g5plus-wolverine' ),
					'xing' => __( 'Xing', 'g5plus-wolverine' ),
					'behance'  => __( 'Behance', 'g5plus-wolverine' ),
					'deviantart'  => __( 'Deviantart', 'g5plus-wolverine' ),
					'soundcloud'  => __( 'SoundCloud', 'g5plus-wolverine' ),
					'yelp'  => __( 'Yelp', 'g5plus-wolverine' ),
					'rss'  => __( 'RSS Feed', 'g5plus-wolverine' ),
					'email'  => __( 'Email address', 'g5plus-wolverine' ),
				)
			)

		);
		parent::__construct();
	}
	function widget( $args, $instance ) {
		if ( $this->get_cached_widget( $args ) )
			return;
		extract( $args, EXTR_SKIP );
		$title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : '';
		$avatar = ( ! empty( $instance['avatar'] ) ) ? $instance['avatar'] : '';
		$social        = empty( $instance['social'] ) ? '' : apply_filters( 'widget_icons', $instance['social'] );

		$social_icons = g5plus_get_social_icon($social,'about-social');
		$class = array('widget-about-wrap');

		ob_start();
		if (!empty($avatar)) : ?>
			<?php echo $args['before_widget']; ?>
			<?php if ( $title ) {
				echo $args['before_title'] . $title . $args['after_title'];
			} ?>
			<div class="<?php echo join(' ',$class); ?>">
				<img alt="<?php echo esc_attr(__('About me','g5plus-wolverine')) ?>" src="<?php echo esc_url($avatar) ?>" />
				<?php echo wp_kses_post( $social_icons ); ?>
			</div>
			<?php echo $args['after_widget']; ?>
		<?php endif;
		// Reset the global $the_post as this query will have stomped on it
		$content =  ob_get_clean();
		echo $content;
		$this->cache_widget( $args, $content );
	}
}

if (!function_exists('g5plus_register_widget_about')) {
	function g5plus_register_widget_about() {
		register_widget('G5Plus_Widget_About');
	}
	add_action('widgets_init', 'g5plus_register_widget_about', 1);
}