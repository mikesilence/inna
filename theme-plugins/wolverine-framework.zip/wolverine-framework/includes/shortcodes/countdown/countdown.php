<?php
if ( ! defined( 'ABSPATH' ) ) die( '-1' );
if(!class_exists('g5plusFramework_Shortcode_Countdown')){
    class g5plusFramework_Shortcode_Countdown {
        function __construct() {
            add_action( 'init', array($this, 'register_post_types' ), 6 );
            add_shortcode('wolverine_countdown_shortcode', array($this, 'wolverine_countdown_shortcode' ));
            add_filter( 'rwmb_meta_boxes', array($this,'wolverine_register_meta_boxes' ));
        }

        function register_post_types() {
            if ( post_type_exists('countdown') ) {
                return;
            }
            register_post_type('countdown',
                array(
                    'label' => __('Countdown','g5plus-wolverine'),
                    'description' => __( 'Countdown Description', 'g5plus-wolverine' ),
                    'labels' => array(
                        'name'					=>'Countdown',
                        'singular_name' 		=> 'Countdown',
                        'menu_name'    			=> __( 'Countdown', 'g5plus-wolverine' ),
                        'parent_item_colon'  	=> __( 'Parent Item:', 'g5plus-wolverine' ),
                        'all_items'          	=> __( 'All Countdown', 'g5plus-wolverine' ),
                        'view_item'          	=> __( 'View Item', 'g5plus-wolverine' ),
                        'add_new_item'       	=> __( 'Add New Countdown', 'g5plus-wolverine' ),
                        'add_new'            	=> __( 'Add New', 'g5plus-wolverine' ),
                        'edit_item'          	=> __( 'Edit Item', 'g5plus-wolverine' ),
                        'update_item'        	=> __( 'Update Item', 'g5plus-wolverine' ),
                        'search_items'       	=> __( 'Search Item', 'g5plus-wolverine' ),
                        'not_found'          	=> __( 'Not found', 'g5plus-wolverine' ),
                        'not_found_in_trash' 	=> __( 'Not found in Trash', 'g5plus-wolverine' ),
                    ),
                    'supports'    => array( 'title', 'editor', 'comments', 'thumbnail'),
                    'public'      => true,
                    'menu_icon' => 'dashicons-clock',
                    'has_archive' => true
                )
            );
        }

        function wolverine_countdown_shortcode($atts){
            $type = $css = '';
            extract( shortcode_atts( array(
                'type'     => '',
                'css'      => ''
            ), $atts ) );

            $plugin_path =  untrailingslashit( plugin_dir_path( __FILE__ ) );
            $template_path = $plugin_path . '/templates/'.$type.'.php';
            ob_start();
            include($template_path);
            $ret = ob_get_contents();
            ob_end_clean();
            return $ret;
        }

        function wolverine_register_meta_boxes($meta_boxes){
            $meta_boxes[] = array(
                'title'  => __( 'Countdown Option', 'g5plus-wolverine' ),
                'id'     => 'wolverine-meta-box-countdown-opening',
                'pages'  => array( 'countdown' ),
                'fields' => array(
                    array(
                        'name' => __( 'Opening hours', 'g5plus-wolverine' ),
                        'id'   => 'countdown-opening',
                        'type' => 'datetime',
                    ),
                     array(
                         'name' => __( 'Type', 'g5plus-wolverine' ),
                         'id'   => 'countdown-type',
                         'type' => 'select',
                         'options'  => array(
                             'comming-soon' => __('Coming Soon','g5plus-wolverine'),
                             'under-construction' => __('Under Construction','g5plus-wolverine')
                         )
                     ),
                    array(
                        'name' => __( 'Url redirect (after countdown completed)', 'g5plus-wolverine' ),
                        'id'   => 'countdown-url',
                        'type' => 'textarea',
                    )
                )
            );
            return $meta_boxes;
        }
    }
    new g5plusFramework_Shortcode_Countdown();
}