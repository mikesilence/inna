<?php
$meta_values = get_post_meta(get_the_ID(), 'gallery-format-gallery', false);
if (count($meta_values) > 0) {
    foreach ($meta_values as $image) {
        ?>
        <div class="g5plus-gallery-item hover-dir">
            <?php
            $post_thumbnail_id = get_post_thumbnail_id(  get_the_ID() );
            $arrImages =  wp_get_attachment_image_src($image, 'full');
            $width = 475;
            $height = 475;
            $thumbnail_url = '';
            if(count($arrImages)>0){
                $resize = matthewruddy_image_resize($arrImages[0],$width,$height);
                if($resize!=null && is_array($resize) )
                    $thumbnail_url = $resize['url'];
            }

            $url_origin = $arrImages[0];
            include(plugin_dir_path( __FILE__ ).'/overlay/'. $overlay_style .'.php');

            ?>

        </div>
    <?php
    }
}
?>